# CommunityConnectNT

Emergency warnings, shelters and help for the Northern Territory, in the
languages people in Darwin actually speak.

**This is a prototype. It is not an official emergency service.**
Always follow AusAlert, the Bureau of Meteorology and SecureNT.

---

## What is in here

| Path | What it is |
| --- | --- |
| `index.html` | The whole app. One file: markup, styles and script. |
| `scripts/fetch_warnings.py` | Reads NT warnings from the Bureau's FTP service and writes `warnings.json`. Python standard library only, no packages to install. |
| `.github/workflows/warnings.yml` | Runs that script every 10 minutes on GitHub's servers and commits the result. |

The app looks for `warnings.json` next to itself. If the file is missing it
falls back to clearly-labelled example data. If the file is there but older
than 30 minutes, the app hides every warning and tells the reader to go to an
official source instead.

---

## Step 1 — Run it on your own computer

You do not need a web server for this, but using one avoids browser security
warnings about local files.

```bash
cd communityconnectnt
python3 -m http.server 8000
```

Then open <http://localhost:8000> in your browser.

To stop it, press `Ctrl + C`.

## Step 2 — Test the warnings script

```bash
python3 scripts/fetch_warnings.py
```

It prints every NT warning file it finds on the Bureau's FTP service and
writes `warnings.json` into the folder. Reload the browser and the app should
switch from "Sample data" to "Live from the Bureau of Meteorology".

If the Bureau has no warnings in force, the file will be nearly empty. That is
correct behaviour, not a bug.

## Step 3 — Put it on GitHub

Create an empty repository on GitHub first. Do not add a README there, because
this folder already has one.

```bash
cd communityconnectnt
git init
git add .
git commit -m "First version of CommunityConnectNT"
git branch -M main
git remote add origin https://github.com/subediparku-eng/communityconnectnt.git
git push -u origin main
```

## Step 4 — Turn on GitHub Pages

In the repository on github.com:

1. **Settings** → **Pages**
2. Under **Source**, choose **Deploy from a branch**
3. Branch: `main`, folder: `/ (root)`, then **Save**

After a minute or two the app is live at:

```
https://subediparku-eng.github.io/communityconnectnt/
```

## Step 5 — Let the robot write warnings.json

The scheduled job needs permission to commit back to your own repository.
This is the step people usually miss.

1. **Settings** → **Actions** → **General**
2. Scroll to **Workflow permissions**
3. Choose **Read and write permissions**, then **Save**

Then run it once by hand to check it works:

1. Open the **Actions** tab
2. Choose **Update NT warnings** on the left
3. **Run workflow** → **Run workflow**

Watch the run. If it goes green and a `warnings.json` appears in the
repository, it is working. From then on it runs every 10 minutes on its own.

---

## Before you make the site public

The Bureau's anonymous FTP service is licensed for personal and internal use.
Its own documentation says you may not supply the material to another person,
and that anyone publishing Bureau data should do so as a **Registered User**.

Email **webreg@bom.gov.au** and register before you share the link widely.
It is a free scheme. Building and testing like this is fine; publishing is the
part that needs it.

---

## Things that are deliberately not finished

- **First Languages are listed but switched off.** Kriol, Yolŋu Matha,
  Pitjantjatjara, Warlpiri, Tiwi and Arrernte emergency wording has to come
  from accredited interpreters and be checked with community representatives.
  The Aboriginal Interpreter Service is the right partner, and the Bureau
  already works with them during cyclones.
- **The shelter list is from the SecureNT website**, which publishes it as
  plain HTML with no capacity figures and no feed. Treat it as a starting
  point, not as live data.
- **The weather card still uses example data.** The fetch script for it has
  not been written yet.

---

## Licence and credit

Warnings and weather data come from the Australian Government Bureau of
Meteorology. Shelter information comes from SecureNT, Northern Territory
Government. Neither endorses this app.

Built by Prakash Subedi, Charles Darwin University.
